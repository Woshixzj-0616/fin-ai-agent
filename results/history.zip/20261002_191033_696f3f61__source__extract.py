"""从文字层年报提取财务证据，按表头文字和坐标识别年份、单位与调整列。"""
from __future__ import annotations

import re

import pymupdf

from materials import Run, sha256, within
from finance import convert, decimal, text

METRICS = {
    "revenue": ("营业收入", "营业收入"),
    "parent_net_profit": ("归母净利润", "归属于上市公司股东的净利润"),
    "adjusted_parent_net_profit": ("扣非归母净利润", "归属于上市公司股东的扣除非经常性损益的净利润"),
    "operating_cash_flow": ("经营现金流净额", "经营活动产生的现金流量净额"),
}


def norm(value: str) -> str:
    return re.sub(r"\s+", "", value)


def box(rect) -> list[float]:
    return [round(float(n), 3) for n in rect]


def table_cells(table) -> list[dict]:
    unique = {}
    for texts, row in zip(table.extract(), table.rows):
        for raw, rect in zip(texts, row.cells):
            if rect is not None:
                unique[tuple(rect)] = {"raw": raw or "", "text": norm(raw or ""),
                                       "bbox": box(rect)}
    return list(unique.values())


def header_for(cell: dict, cells: list[dict], pattern: str) -> dict | None:
    """多层表头：找覆盖数值单元格横向中心、且位于它上方的最近表头。"""
    x0, y0, x1, _ = cell["bbox"]
    center = (x0 + x1) / 2
    candidates = [c for c in cells
                  if re.fullmatch(pattern, c["text"])
                  and c["bbox"][0] <= center <= c["bbox"][2]
                  and c["bbox"][3] <= y0 + 1]
    return max(candidates, key=lambda c: c["bbox"][3]) if candidates else None


def amount_cell(cell: dict) -> bool:
    value = cell["text"].replace(",", "").replace("，", "")
    return bool(re.fullmatch(r"[-−]?\d+(?:\.\d+)?|[（(]\d+(?:\.\d+)?[）)]", value))


def label_for(anchor: dict, cells: list[dict]) -> tuple[str, list[float]]:
    x0, y0, _, y1 = anchor["bbox"]
    parts = [c for c in cells if c["text"] and not amount_cell(c)
             and c["text"] not in {"-", "—", "–"}
             and c["bbox"][2] <= x0 + 1
             and c["bbox"][0] < x0 - 10
             and y0 <= (c["bbox"][1] + c["bbox"][3]) / 2 <= y1]
    parts.sort(key=lambda c: (c["bbox"][1], c["bbox"][0]))
    if not parts:
        return "", []
    return "".join(c["text"] for c in parts), [
        min(c["bbox"][0] for c in parts), min(c["bbox"][1] for c in parts),
        max(c["bbox"][2] for c in parts), max(c["bbox"][3] for c in parts)]


def metric_for(label: str) -> str | None:
    clean = re.sub(r"[（(](?:人民币)?(?:亿|万)?元[）)]$", "", label)
    return next((key for key, (_, alias) in METRICS.items() if clean == alias), None)


def document_currency(document, texts: list[str]) -> dict | None:
    for index, content in enumerate(texts):
        compact = norm(content)
        found = re.search(r"(?:以人民币.{0,20}(?:记账本位币|报告货币)|"
                          r"本(?:公司|财务报表).{0,12}人民币.{0,12}(?:记账本位币|列报|列示))",
                          compact)
        if found:
            return {"currency": "CNY", "page": index + 1, "quote": found[0],
                    "basis": "document_currency_statement"}
    return None


def statement_sections(document) -> list[dict]:
    markers = []
    for index, page in enumerate(document):
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                title = norm("".join(span["text"] for span in line["spans"]))
                match = re.fullmatch(r"[\d一二三四五六、.（）()]*((?:合并|母公司)(?:利润表|现金流量表))", title)
                if match:
                    markers.append({"title": match[1], "page": index, "bbox": box(line["bbox"])})
    markers.sort(key=lambda item: (item["page"], item["bbox"][1]))
    for i, marker in enumerate(markers):
        marker["end"] = markers[i + 1] if i + 1 < len(markers) else None
    return markers


def corroborate_scope(document, sections: list[dict], fact: dict) -> dict | None:
    wanted = "合并利润表" if fact["metric"] == "revenue" else "合并现金流量表"
    alias = METRICS[fact["metric"]][1]
    value = decimal(fact["value"])
    if value is None or fact["unit"] != "元":
        return None
    formatted = format(value, ",.2f")
    for section in sections:
        if section["title"] != wanted:
            continue
        end = section["end"]
        last = min(section["page"] + 4, end["page"] if end else len(document) - 1)
        for index in range(section["page"], last + 1):
            page = document[index]
            hits = page.search_for(formatted) or page.search_for(format(value, ".2f"))
            for hit in hits:
                if index == section["page"] and hit.y0 <= section["bbox"][3]:
                    continue
                if end and index == end["page"] and hit.y1 >= end["bbox"][1]:
                    continue
                label_region = pymupdf.Rect(page.rect.x0, hit.y0 - 18, hit.x0 - 1, hit.y1 + 18)
                label = norm(page.get_text(clip=label_region))
                if alias in label:
                    return {"scope": "consolidated", "basis": "corroborated_current_value_in_statement",
                            "page": index + 1, "value_bbox": box(hit), "row_context": label,
                            "section_title": wanted, "section_page": section["page"] + 1,
                            "section_bbox": section["bbox"]}
    return None


def parse_table(page, table, table_index: int, material: dict, currency_note) -> list[dict]:
    cells = table_cells(table)
    above = page.get_text(clip=pymupdf.Rect(table.bbox[0], max(0, table.bbox[1] - 65),
                                          page.rect.x1, table.bbox[1]))
    above_compact = norm(above)
    unit_match = re.search(r"单位[:：]?(?:人民币)?(亿元|万元|元)", above_compact)
    page_currency = {"currency": "CNY", "page": page.number + 1, "quote": above_compact,
                     "basis": "table_unit_heading"} if "人民币" in above_compact else currency_note
    facts, seen_rows = [], set()
    for anchor in cells:
        if not amount_cell(anchor) or anchor["bbox"][2] - anchor["bbox"][0] < 25:
            continue
        if not header_for(anchor, cells, r"20\d{2}年(?:度)?"):
            continue
        label, label_bbox = label_for(anchor, cells)
        metric = metric_for(label)
        if not metric:
            continue
        row_key = (metric, anchor["bbox"][1])
        if row_key in seen_rows:
            continue
        seen_rows.add(row_key)
        # anchor可能是后面的数值列；从标签右侧重新取整行。
        row_cells = [c for c in cells if abs(c["bbox"][1] - anchor["bbox"][1]) < 1
                     and c["bbox"][0] >= label_bbox[2] - 1
                     and c["bbox"][2] - c["bbox"][0] >= 25]
        row_unit = re.search(r"[（(](?:人民币)?(亿元|万元|元)[）)]", label)
        unit = row_unit[1] if row_unit else unit_match[1] if unit_match else None
        reported_yoy = None
        for cell in row_cells:
            rate_header = header_for(cell, cells, r".*本[年期].*比.*增减.*")
            rate = re.match(r"^(-?\d+(?:\.\d+)?)(%|％)?", cell["text"])
            if rate_header and rate and ("%" in rate_header["text"] or rate[2]):
                reported_yoy = {"value": rate[1], "unit": "%", "bbox": cell["bbox"],
                                "header": rate_header}
        for cell in row_cells:
            header = header_for(cell, cells, r"20\d{2}年(?:度)?")
            if not header:
                continue
            year = int(header["text"][:4])
            adjustment = header_for(cell, cells, r"调整前|调整后")
            adjustment_kind = {"调整前": "before", "调整后": "after"}.get(
                adjustment["text"] if adjustment else "", "as_reported")
            raw = cell["text"]
            if not amount_cell(cell) and raw not in {"", "-", "—", "–"}:
                continue
            value = decimal(raw)
            normalized = convert(value, unit) if unit else None
            table_id = f"p{page.number + 1}_t{table_index}"
            identity = f"{material['document_id']}|{table_id}|{metric}|{year}|{adjustment_kind}"
            issues = []
            if unit is None:
                issues.append("unit_unknown")
            if not page_currency:
                issues.append("currency_unknown")
            if value is None:
                issues.append("value_missing")
            parent_metric = metric in {"parent_net_profit", "adjusted_parent_net_profit"}
            facts.append({
                "schema_version": 1, "evidence_id": sha256(identity.encode())[:24],
                "document_id": material["document_id"],
                "company_code": material["company_code"], "company_name": material["company_name"],
                "metric": metric, "metric_name": METRICS[metric][0], "original_label": label,
                "report_year": material["report_year"], "period_year": year,
                "period_start": f"{year}-01-01", "period_end": f"{year}-12-31",
                "period_kind": "annual", "duration_months": 12,
                "value": text(value), "raw_value": cell["raw"], "unit": unit,
                "normalized_value": text(normalized), "normalized_unit": "元" if unit else None,
                "currency": page_currency["currency"] if page_currency else None,
                "currency_evidence": page_currency,
                "scope": "parent_shareholders" if parent_metric else "unknown",
                "scope_evidence": {"basis": "explicit_metric_label", "quote": label,
                                   "page": page.number + 1} if parent_metric else None,
                "adjustment": adjustment_kind,
                "comparison_group": material["document_id"] + "|" + table_id,
                "source_file": material["local_file"], "source_sha256": material["sha256"],
                "announcement_id": material["announcement_id"],
                "source_url": material["source_url"], "page": page.number + 1,
                "page_label": page.get_label(), "table_id": table_id,
                "table_bbox": box(table.bbox), "value_bbox": cell["bbox"],
                "label_bbox": label_bbox, "year_header": header,
                "adjustment_header": adjustment, "reported_yoy": reported_yoy,
                "has_adjustment_columns": any(c["text"] in {"调整前", "调整后"} for c in cells),
                "issues": issues, "extraction_method": "grid_cells_and_geometric_headers",
            })
    return facts


def extract_material(root, material: dict, run: Run) -> list[dict]:
    path = within(root, root / material["local_file"])
    blob = run.read(path)
    if sha256(blob) != material["sha256"]:
        raise ValueError("提取前指纹复核失败")
    with pymupdf.open(stream=blob, filetype="pdf") as document:
        texts = [page.get_text() for page in document]
        currency = document_currency(document, texts)
        candidates = []
        for index, content in enumerate(texts):
            compact = norm(content)
            if "主要会计数据" not in compact or "营业收入" not in compact:
                continue
            page = document[index]
            for ti, table in enumerate(page.find_tables().tables):
                facts = parse_table(page, table, ti, material, currency)
                current = [f for f in facts if f["period_year"] == material["report_year"]]
                count = len({f["metric"] for f in current})
                if count:
                    candidates.append((count, facts))
        if not candidates:
            raise ValueError("未识别年度主要会计数据表；可能无文字层、无表格线或版式不支持")
        best_count = max(count for count, _ in candidates)
        best = [facts for count, facts in candidates if count == best_count]
        signatures = {
            tuple(sorted((f["metric"], f["period_year"], f["adjustment"], f["value"] or "")
                         for f in facts)) for facts in best}
        if len(signatures) != 1:
            raise ValueError("发现互相冲突的候选表，需要人工选择")
        facts = best[0]
        keys = [(f["metric"], f["period_year"], f["adjustment"]) for f in facts]
        if len(keys) != len(set(keys)):
            raise ValueError("表头产生重复证据键，拒绝静默选列")
        sections = statement_sections(document)
        for metric in ("revenue", "operating_cash_flow"):
            current = next((f for f in facts if f["metric"] == metric
                            and f["period_year"] == material["report_year"]), None)
            corroboration = corroborate_scope(document, sections, current) if current else None
            for fact in facts:
                if fact["metric"] == metric:
                    if corroboration:
                        fact["scope"] = "consolidated"
                        fact["scope_evidence"] = {
                            **corroboration, "application": "same_summary_metric_row",
                            "confirmed_current_evidence_id": current["evidence_id"]}
                    else:
                        fact["issues"].append("scope_unknown")
        missing = sorted(set(METRICS) - {f["metric"] for f in facts
                                        if f["period_year"] == material["report_year"]})
        run.event("extraction_completed", document_id=material["document_id"],
                  evidence_count=len(facts), missing_current_metrics=missing,
                  needs_review=sum(bool(f["issues"]) for f in facts))
        if missing:
            raise ValueError("主要指标不完整：" + ",".join(missing))
        return facts
