"""从文字层年报提取财务证据：words 级稳健解析 + 表格线网格解析双通道。

合流口径（2026-10-02）：
  - words 级（words.py）为主路径 —— 主仓 extract_metrics.py 那套版式解析，70/70 稳健；
  - 表格线网格（find_tables）为回退 —— 保留 bbox/调整列/披露同比的精细字段，护住 24 条 gold；
  - 指标目录 4 → 14，另从「合并利润表」补 `营业总收入`（口径陷阱指标，摘要表常不列）。
证据 schema 不变：value 可计算字符串、normalized 统一为元、每条带页码与 bbox。
"""
from __future__ import annotations

import re

import pymupdf

from materials import Run, sha256, within
from finance import convert, decimal, text
from words import (
    AMOUNT_UNITS, HEADER_MAX_ABOVE, LABEL_SIT, METRIC_UNIT, PAREN_RE, YEAR_CELL_RE,
    classify_unit, common_label_unit, declared_unit, heading_ys,
    match_metric_at, norm, page_rows, row_unit, tail_carry, to_num,
    year_header_groups,
)

# 指标目录：key → (中文名, 别名列表)。别名按「长的在前」写，避免短名吃掉长名。
# 前 4 个 key 是 gold 参考答案在用的，**不能改名**。
METRICS: dict[str, tuple[str, list[str]]] = {
    "total_revenue": ("营业总收入", ["营业总收入"]),
    "revenue": ("营业收入", ["营业收入"]),
    "parent_net_profit": ("归母净利润", [
        "归属于上市公司股东的净利润", "归属于母公司股东的净利润",
        "归属于母公司所有者的净利润", "归属于本行股东的净利润",
        "归属于本公司股东的净利润"]),
    "adjusted_parent_net_profit": ("扣非归母净利润", [
        "归属于上市公司股东的扣除非经常性损益的净利润",
        "归属于母公司股东的扣除非经常性损益的净利润",
        "归属于母公司所有者的扣除非经常性损益的净利润",
        "扣除非经常性损益后的归属于上市公司股东的净利润",
        "扣除非经常性损益后归属于上市公司股东的净利润",
        "扣除非经常性损益后归属于母公司股东的净利润",
        "扣除非经常性损益后归属于本行股东的净利润",
        "归属于本公司股东的扣除非经常性损益的净利润",
        "归属于母公司股东的扣除非经常性损益后的净利润",
        "扣除非经常性损益后归属于本公司股东的净利润"]),
    "operating_cash_flow": ("经营现金流净额", ["经营活动产生的现金流量净额"]),
    "basic_eps": ("基本每股收益", ["基本每股收益"]),
    "diluted_eps": ("稀释每股收益", ["稀释每股收益"]),
    "deducted_basic_eps": ("扣非基本每股收益", [
        "扣除非经常性损益后的基本每股收益"]),
    "weighted_roe": ("加权平均净资产收益率", [
        "加权平均净资产收益率", "净资产收益率（加权平均）", "净资产收益率(加权平均)"]),
    "deducted_weighted_roe": ("扣非加权平均净资产收益率", [
        "扣除非经常性损益后的加权平均净资产收益率"]),
    "total_assets": ("总资产", ["总资产", "资产总额", "资产总计"]),
    "parent_equity": ("归母净资产", [
        "归属于上市公司股东的净资产", "归属于母公司股东的净资产",
        "归属于母公司所有者权益", "归属于上市公司股东的所有者权益",
        "归属于本行股东权益", "归属于母公司股东权益", "归属于本公司股东权益",
        "归属于本行股东的净资产", "归属于本公司股东的净资产"]),
    "book_value_per_share": ("每股净资产", [
        "归属于上市公司股东的每股净资产", "归属于母公司股东的每股净资产",
        "归属于上市公司普通股股东的每股净资产", "归属于本行普通股股东的每股净资产",
        "每股净资产"]),
    "revenue_after_deduction": ("营业收入扣除后金额", [
        "营业收入扣除后金额", "扣除后营业收入"]),
}

# 别名长优先，同长按目录序 —— 「营业总收入」先于「营业收入」，「扣非基本每股收益」先于「基本每股收益」。
ALIASES: list[tuple[str, str, int]] = []
for _idx, (_key, (_name, _names)) in enumerate(METRICS.items()):
    for _alias in _names:
        ALIASES.append((_alias, _key, _idx))
ALIASES.sort(key=lambda t: (-len(t[0]), t[2]))

# 抽不出来就报错的指标（gold 与核查器的最小集合）；其余缺了只记录，不阻断。
REQUIRED = ("revenue", "parent_net_profit", "adjusted_parent_net_profit", "operating_cash_flow")
PARENT_METRICS = {"parent_net_profit", "adjusted_parent_net_profit"}
CONSOLIDATED_METRICS = {"revenue", "operating_cash_flow", "total_revenue", "revenue_after_deduction"}


def box(rect) -> list[float]:
    return [round(float(n), 3) for n in rect]


def cell_bbox(c: dict) -> list[float]:
    return [round(float(c["x0"]), 3), round(float(c["y0"]), 3),
            round(float(c["x1"]), 3), round(float(c["y1"]), 3)]


# ─────────────────────────── 表格线网格路径（回退，护 gold） ───────────────────────────

def table_cells(table) -> list[dict]:
    unique = {}
    for texts, row in zip(table.extract(), table.rows):
        for raw, rect in zip(texts, row.cells):
            if rect is not None:
                unique[tuple(rect)] = {"raw": raw or "", "text": norm(raw or ""),
                                       "bbox": box(rect)}
    return list(unique.values())


def header_for(cell: dict, cells: list[dict], pattern: str) -> dict | None:
    """多层表头：找覆盖数值单元格横向中心、且位于它上方的最近表头。"""
    x0, y0, x1, _ = cell["bbox"]
    center = (x0 + x1) / 2
    candidates = [c for c in cells
                  if re.fullmatch(pattern, c["text"])
                  and c["bbox"][0] <= center <= c["bbox"][2]
                  and c["bbox"][3] <= y0 + 1]
    return max(candidates, key=lambda c: c["bbox"][3]) if candidates else None


def amount_cell(cell: dict) -> bool:
    value = cell["text"].replace(",", "").replace("，", "")
    return bool(re.fullmatch(r"[-−]?\d+(?:\.\d+)?|[（(]\d+(?:\.\d+)?[）)]", value))


def label_for(anchor: dict, cells: list[dict]) -> tuple[str, list[float]]:
    x0, y0, _, y1 = anchor["bbox"]
    parts = [c for c in cells if c["text"] and not amount_cell(c)
             and c["text"] not in {"-", "—", "–"}
             and c["bbox"][2] <= x0 + 1
             and c["bbox"][0] < x0 - 10
             and y0 <= (c["bbox"][1] + c["bbox"][3]) / 2 <= y1]
    parts.sort(key=lambda c: (c["bbox"][1], c["bbox"][0]))
    if not parts:
        return "", []
    return "".join(c["text"] for c in parts), [
        min(c["bbox"][0] for c in parts), min(c["bbox"][1] for c in parts),
        max(c["bbox"][2] for c in parts), max(c["bbox"][3] for c in parts)]


def metric_for(label: str):
    clean = re.sub(r"[（(](?:人民币)?(?:亿|万)?元[）)]$", "", label)
    return match_metric_at(clean, ALIASES)[0]


def document_currency(document, texts: list[str]) -> dict | None:
    for index, content in enumerate(texts):
        compact = norm(content)
        found = re.search(r"(?:以人民币.{0,20}(?:记账本位币|报告货币)|"
                          r"本(?:公司|财务报表).{0,12}人民币.{0,12}(?:记账本位币|列报|列示))",
                          compact)
        if found:
            return {"currency": "CNY", "page": index + 1, "quote": found[0],
                    "basis": "document_currency_statement"}
    return None


def statement_sections(document) -> list[dict]:
    markers = []
    for index, page in enumerate(document):
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                title = norm("".join(span["text"] for span in line["spans"]))
                match = re.fullmatch(r"[\d一二三四五六、.（()）]*((?:合并|母公司)(?:利润表|现金流量表))", title)
                if match:
                    markers.append({"title": match[1], "page": index, "bbox": box(line["bbox"])})
    markers.sort(key=lambda item: (item["page"], item["bbox"][1]))
    for i, marker in enumerate(markers):
        marker["end"] = markers[i + 1] if i + 1 < len(markers) else None
    return markers


def corroborate_scope(document, sections: list[dict], fact: dict) -> dict | None:
    wanted = "合并利润表" if fact["metric"] in PARENT_METRICS or fact["metric"] in ("revenue", "total_revenue") \
        else "合并现金流量表"
    alias = METRICS[fact["metric"]][1][0]
    value = decimal(fact["value"])
    if value is None or fact["unit"] != "元":
        return None
    formatted = format(value, ",.2f")
    for section in sections:
        if section["title"] != wanted:
            continue
        end = section["end"]
        last = min(section["page"] + 4, end["page"] if end else len(document) - 1)
        for index in range(section["page"], last + 1):
            page = document[index]
            hits = page.search_for(formatted) or page.search_for(format(value, ".2f"))
            for hit in hits:
                if index == section["page"] and hit.y0 <= section["bbox"][3]:
                    continue
                if end and index == end["page"] and hit.y1 >= end["bbox"][1]:
                    continue
                label_region = pymupdf.Rect(page.rect.x0, hit.y0 - 18, hit.x0 - 1, hit.y1 + 18)
                label = norm(page.get_text(clip=label_region))
                if alias in label:
                    return {"scope": "consolidated", "basis": "corroborated_current_value_in_statement",
                            "page": index + 1, "value_bbox": box(hit), "row_context": label,
                            "section_title": wanted, "section_page": section["page"] + 1,
                            "section_bbox": section["bbox"]}
    return None


def parse_table(page, table, table_index: int, material: dict, currency_note) -> list[dict]:
    cells = table_cells(table)
    above = page.get_text(clip=pymupdf.Rect(table.bbox[0], max(0, table.bbox[1] - 65),
                                           page.rect.x1, table.bbox[1]))
    above_compact = norm(above)
    unit_match = re.search(r"单位[:：]?(?:人民币)?(亿元|万元|元)", above_compact)
    page_currency = {"currency": "CNY", "page": page.number + 1, "quote": above_compact,
                     "basis": "table_unit_heading"} if "人民币" in above_compact else currency_note
    facts, seen_rows = [], set()
    for anchor in cells:
        if not amount_cell(anchor) or anchor["bbox"][2] - anchor["bbox"][0] < 25:
            continue
        if not header_for(anchor, cells, r"20\d{2}年(?:度)?"):
            continue
        label, label_bbox = label_for(anchor, cells)
        metric = metric_for(label)
        if not metric:
            continue
        row_key = (metric, anchor["bbox"][1])
        if row_key in seen_rows:
            continue
        seen_rows.add(row_key)
        row_cells = [c for c in cells if abs(c["bbox"][1] - anchor["bbox"][1]) < 1
                     and c["bbox"][0] >= label_bbox[2] - 1
                     and c["bbox"][2] - c["bbox"][0] >= 25]
        row_unit_m = re.search(r"[（(](?:人民币)?(亿元|万元|元)[）)]", label)
        unit = row_unit_m[1] if row_unit_m else unit_match[1] if unit_match else None
        reported_yoy = None
        for cell in row_cells:
            rate_header = header_for(cell, cells, r".*本[年期].*比.*增减.*")
            rate = re.match(r"^(-?\d+(?:\.\d+)?)(%|％)?", cell["text"])
            if rate_header and rate and ("%" in rate_header["text"] or rate[2]):
                reported_yoy = {"value": rate[1], "unit": "%", "bbox": cell["bbox"],
                                "header": rate_header}
        for cell in row_cells:
            header = header_for(cell, cells, r"20\d{2}年(?:度)?")
            if not header:
                continue
            year = int(header["text"][:4])
            adjustment = header_for(cell, cells, r"调整前|调整后")
            adjustment_kind = {"调整前": "before", "调整后": "after"}.get(
                adjustment["text"] if adjustment else "", "as_reported")
            raw = cell["text"]
            if not amount_cell(cell) and raw not in {"", "-", "—", "–"}:
                continue
            value = decimal(raw)
            normalized = convert(value, unit) if unit else None
            table_id = f"p{page.number + 1}_t{table_index}"
            identity = f"{material['document_id']}|{table_id}|{metric}|{year}|{adjustment_kind}"
            issues = []
            if unit is None:
                issues.append("unit_unknown")
            if not page_currency:
                issues.append("currency_unknown")
            if value is None:
                issues.append("value_missing")
            parent_metric = metric in PARENT_METRICS
            facts.append({
                "schema_version": 1, "evidence_id": sha256(identity.encode())[:24],
                "document_id": material["document_id"],
                "company_code": material["company_code"], "company_name": material["company_name"],
                "metric": metric, "metric_name": METRICS[metric][0], "original_label": label,
                "report_year": material["report_year"], "period_year": year,
                "period_start": f"{year}-01-01", "period_end": f"{year}-12-31",
                "period_kind": "annual", "duration_months": 12,
                "value": text(value), "raw_value": cell["raw"], "unit": unit,
                "normalized_value": text(normalized), "normalized_unit": "元" if unit else None,
                "currency": page_currency["currency"] if page_currency else None,
                "currency_evidence": page_currency,
                "scope": "parent_shareholders" if parent_metric else "unknown",
                "scope_evidence": {"basis": "explicit_metric_label", "quote": label,
                                   "page": page.number + 1} if parent_metric else None,
                "adjustment": adjustment_kind,
                "comparison_group": material["document_id"] + "|" + table_id,
                "source_file": material["local_file"], "source_sha256": material["sha256"],
                "announcement_id": material["announcement_id"],
                "source_url": material["source_url"], "page": page.number + 1,
                "page_label": page.get_label(), "table_id": table_id,
                "table_bbox": box(table.bbox), "value_bbox": cell["bbox"],
                "label_bbox": label_bbox, "year_header": header,
                "adjustment_header": adjustment, "reported_yoy": reported_yoy,
                "has_adjustment_columns": any(c["text"] in {"调整前", "调整后"} for c in cells),
                "issues": issues, "extraction_method": "grid_cells_and_geometric_headers",
            })
    return facts


# ─────────────────────────── words 级主路径 ───────────────────────────

# 折行标签的搜索窗与「同处一行」容差见 words.py；这里只管取数。
UNIT_IN_LABEL_RE = re.compile(r"[（(](?:人民币)?(亿元|万元|千元|百万元|元)[）)]")


def _emit_words_fact(*, material, page, metric, label, label_fragments, raw, value,
                     unit, year, year_cell, adjustment_cell, reported_yoy_cell,
                     value_cell, table_rows, page_currency, method):
    """把 words 级解析出的一格，落成一条与网格路径同 schema 的证据。"""
    normalized = convert(value, unit) if unit else None
    table_id = f"p{page.number + 1}_w"
    adjustment_kind = {"调整前": "before", "调整后": "after"}.get(
        adjustment_cell["text"] if adjustment_cell else "", "as_reported")
    identity = f"{material['document_id']}|{table_id}|{metric}|{year}|{adjustment_kind}"
    issues = []
    if unit is None:
        issues.append("unit_unknown")
    if not page_currency:
        issues.append("currency_unknown")
    if value is None:
        issues.append("value_missing")
    label_bbox = []
    if label_fragments:
        label_bbox = [min(f["x0"] for f in label_fragments), min(f["y0"] for f in label_fragments),
                      max(f["x1"] for f in label_fragments), max(f["y1"] for f in label_fragments)]
        label_bbox = [round(float(n), 3) for n in label_bbox]
    parent_metric = metric in PARENT_METRICS
    row_y = value_cell["yc"]
    table_bbox = [round(float(min(c["x0"] for r in table_rows for c in r["cells"])), 3),
                  round(float(min(c["y0"] for r in table_rows for c in r["cells"])), 3),
                  round(float(max(c["x1"] for r in table_rows for c in r["cells"])), 3),
                  round(float(max(c["y1"] for r in table_rows for c in r["cells"])), 3)]
    return {
        "schema_version": 1, "evidence_id": sha256(identity.encode())[:24],
        "document_id": material["document_id"],
        "company_code": material["company_code"], "company_name": material["company_name"],
        "metric": metric, "metric_name": METRICS[metric][0], "original_label": label,
        "report_year": material["report_year"], "period_year": year,
        "period_start": f"{year}-01-01", "period_end": f"{year}-12-31",
        "period_kind": "annual", "duration_months": 12,
        "value": text(value), "raw_value": raw, "unit": unit,
        "normalized_value": text(normalized), "normalized_unit": "元" if unit else None,
        "currency": page_currency["currency"] if page_currency else None,
        "currency_evidence": page_currency,
        "scope": "parent_shareholders" if parent_metric else "unknown",
        "scope_evidence": {"basis": "explicit_metric_label", "quote": label,
                           "page": page.number + 1} if parent_metric else None,
        "adjustment": adjustment_kind,
        "comparison_group": material["document_id"] + "|" + table_id,
        "source_file": material["local_file"], "source_sha256": material["sha256"],
        "announcement_id": material["announcement_id"],
        "source_url": material["source_url"], "page": page.number + 1,
        "page_label": page.get_label(), "table_id": table_id,
        "table_bbox": table_bbox, "value_bbox": cell_bbox(value_cell),
        "label_bbox": label_bbox,
        "year_header": {"text": year_cell["text"], "bbox": cell_bbox(year_cell)},
        "adjustment_header": ({"text": adjustment_cell["text"], "bbox": cell_bbox(adjustment_cell)}
                              if adjustment_cell else None),
        "reported_yoy": reported_yoy_cell,
        "has_adjustment_columns": any(
            c["text"] in {"调整前", "调整后"} for r in table_rows for c in r["cells"]),
        "issues": issues, "extraction_method": method,
    }


def _adjustment_cell_for(value_cell: dict, rows: list[dict]) -> dict | None:
    """数值列上方最近的「调整前/调整后」表头格。"""
    xc = (value_cell["x0"] + value_cell["x1"]) / 2
    best = None
    for r in rows:
        for c in r["cells"]:
            if c["text"] in {"调整前", "调整后"} and c["y1"] <= value_cell["y0"] + 1:
                cx = (c["x0"] + c["x1"]) / 2
                if abs(cx - xc) <= YEAR_COL_TOL * 1.5:
                    d = value_cell["y0"] - c["y1"]
                    if best is None or d < best[0]:
                        best = (d, c)
    return best[1] if best else None


def _reported_yoy_for(row: dict, rows: list[dict], label: str) -> dict | None:
    """披露同比：表头带「比…增减」或 % 的列，行内取百分数。"""
    nums = [c for c in row["cells"] if to_num(c["text"]) is not None]
    for c in row["cells"]:
        t = norm(c["text"])
        if not t or t in {"-", "—", "–"}:
            continue
        v = to_num(t)
        if v is None or not (t.endswith("%") or t.endswith("％") or "." in t and abs(v) < 200):
            continue
        # 找它上方最近的、含「增减/比」的表头
        xc = (c["x0"] + c["x1"]) / 2
        for r in rows:
            if r["yc"] >= row["yc"]:
                continue
            for h in r["cells"]:
                ht = norm(h["text"])
                if ("增减" in ht or ("比" in ht and ("上年" in ht or "同期" in ht or "年" in ht))) \
                        and h["x0"] - 2 <= xc <= h["x1"] + 2:
                    rate = re.match(r"^(-?\d+(?:\.\d+)?)", t)
                    if rate:
                        return {"value": rate[1], "unit": "%", "bbox": cell_bbox(c),
                                "header": {"text": h["text"], "bbox": cell_bbox(h)}}
    return None


def extract_via_words(page, report_year, material, currency_note, carry_cols=None):
    """words 级抽一页，返回 (facts, carry_cols)。"""
    rows = page_rows(page)
    for r in rows:
        for c in r["cells"]:
            v = to_num(c["text"])
            if v is not None:
                c["num"] = v
                c["xc"] = (c["x0"] + c["x1"]) / 2
    num_rows = [r for r in rows if sum(1 for c in r["cells"] if "num" in c) >= 2]
    if not num_rows:
        return [], None

    groups = year_header_groups(rows, report_year)
    if not groups and not carry_cols:
        return [], None
    heads = heading_ys(rows)
    page_declared = declared_unit(rows) or common_label_unit(rows)
    above_compact = norm(" ".join("".join(c["text"] for c in r["cells"]) for r in rows[:8]))
    page_currency = ({"currency": "CNY", "page": page.number + 1, "quote": above_compact,
                      "basis": "table_unit_heading"} if "人民币" in above_compact else currency_note)

    num_left = min(c["x0"] for r in num_rows for c in r["cells"] if "num" in c)
    frags = [c for r in rows for c in r["cells"]
             if "num" not in c and c["x0"] < num_left + 1.5 and 0 < len(c["text"]) <= 40]

    buckets = [[] for _ in num_rows]
    for f in frags:
        best = min(range(len(num_rows)), key=lambda i: abs(num_rows[i]["yc"] - f["yc"]))
        buckets[best].append(f)
    for b in buckets:
        b.sort(key=lambda c: c["yc"])

    def label_options(i):
        own = buckets[i]
        out = [own]
        if i + 1 < len(buckets):
            base = num_rows[i + 1]["yc"]
            for d in (1, 2):
                nxt = buckets[i + 1][:d]
                if len(nxt) == d and all(abs(f["yc"] - base) > LABEL_SIT for f in nxt):
                    out.append(own + nxt)
        if i > 0:
            base = num_rows[i - 1]["yc"]
            for d in (1, 2):
                prev = buckets[i - 1][-d:]
                if len(prev) == d and all(abs(f["yc"] - base) > LABEL_SIT for f in prev):
                    out.append(prev + own)
        return out

    facts = []
    found_metrics = set()
    for i, row in enumerate(num_rows):
        strict = metric = chosen_frags = None
        for fs in label_options(i):
            text_joined = norm("".join(f["text"] for f in fs))
            m, pos = match_metric_at(text_joined, ALIASES)
            if m and m not in found_metrics:
                strict, metric, chosen_frags = text_joined[pos:], m, fs
                break
        if metric is None:
            continue
        found_metrics.add(metric)
        label = strict
        above = [g for g in groups if 2.0 < row["yc"] - g[0] <= HEADER_MAX_ABOVE
                 and not any(g[0] < hy < row["yc"] for hy in heads)]
        if above:
            cols = above[-1][1]
        elif carry_cols and not any(hy < row["yc"] for hy in heads):
            cols = carry_cols
        else:
            cols = None
        nums = [c for c in row["cells"] if "num" in c]
        row_unit_val = (METRIC_UNIT.get(metric) or row_unit(strict)
                        or row_unit(label) or page_declared)
        yoy_cell = _reported_yoy_for(row, rows, label)
        for xc, yr, year_cell in cols or []:
            best = None
            for c in nums:
                d = abs(c["xc"] - xc)
                if d <= YEAR_COL_TOL and (best is None or d < best[0]):
                    best = (d, c)
            if best is None:
                continue
            value_cell = best[1]
            # 调整前/调整后：同一财年可能并排两列，都要留。
            adj = _adjustment_cell_for(value_cell, rows)
            facts.append(_emit_words_fact(
                material=material, page=page, metric=metric, label=label,
                label_fragments=chosen_frags or [], raw=value_cell["raw"],
                value=decimal(value_cell["text"]), unit=row_unit_val,
                year=yr, year_cell=year_cell, adjustment_cell=adj,
                reported_yoy_cell=yoy_cell, value_cell=value_cell,
                table_rows=rows, page_currency=page_currency,
                method="words_geometry"))
    return facts, tail_carry(rows, report_year)


def extract_words_document(document, material: dict, currency_note) -> list[dict]:
    """扫全篇主要会计数据页，words 级合并提取。"""
    merged: dict[tuple, dict] = {}
    carry, prev_used = None, False
    for i in range(len(document)):
        content = document[i].get_text()
        hit = ("主要会计数据" in content) or ("主要财务指标" in content)
        if not hit and not prev_used:
            carry = None
            continue
        found, carry = extract_via_words(document[i], material["report_year"],
                                         material, currency_note, carry if prev_used else None)
        if not found:
            prev_used = False
            continue
        prev_used = True
        for rec in found:
            key = (rec["metric"], rec["period_year"], rec["adjustment"])
            if key not in merged:
                merged[key] = rec
    return list(merged.values())


# ─────────────────────────── 营业总收入：合并利润表补抽 ───────────────────────────

TOTAL_REV_LABEL_RE = re.compile(r"^(?:一、)?营业总收入")


def extract_total_revenue(document, material: dict, currency_note) -> list[dict]:
    """从合并利润表补 `营业总收入`。摘要表常不列这一行（茅台 2024 差营业收入 32.4 亿）。"""
    facts = []
    for index, page in enumerate(document):
        content = norm(page.get_text())
        if "营业总收入" not in content or "利润表" not in content:
            continue
        rows = page_rows(page)
        for r in rows:
            for c in r["cells"]:
                c["num"] = to_num(c["text"])
                if c["num"] is not None:
                    c["xc"] = (c["x0"] + c["x1"]) / 2
        # 标签格：整格以「营业总收入」开头（含「一、营业总收入」）
        label_cell = None
        for r in rows:
            for c in r["cells"]:
                t = norm(c["text"])
                if TOTAL_REV_LABEL_RE.match(t) and to_num(t) is None:
                    label_cell = c
                    break
            if label_cell:
                break
        if not label_cell:
            continue
        num_row = next((r for r in rows if r["yc"] >= label_cell["yc"] - 2
                        and sum(1 for c in r["cells"] if c.get("num") is not None) >= 1
                        and abs(r["yc"] - label_cell["yc"]) <= 12), None)
        if not num_row:
            continue
        nums = [c for c in num_row["cells"] if c.get("num") is not None]
        if not nums:
            continue
        # 年份表头：利润表常见「2024年度/2023年度」或「本期/上期」
        groups = year_header_groups(rows, material["report_year"])
        yoy = None
        if groups:
            cols = min(groups, key=lambda g: abs(g[0] - label_cell["yc"]))[1]
            year_map = [(yr, cell) for _, yr, cell in cols]
        else:
            # 本期/上期：按列序左→右 = 本期→上期
            year_map = []
            ordered = sorted(nums, key=lambda c: c["x0"])
            for k, cell in enumerate(ordered[:2]):
                yr = material["report_year"] - k
                year_map.append((yr, {"text": f"{yr}年度", "bbox": cell_bbox(cell),
                                      "x0": cell["x0"], "x1": cell["x1"],
                                      "y0": cell["y0"], "y1": cell["y1"]}))
        for yr, year_cell in year_map:
            xc = (year_cell["x0"] + year_cell["x1"]) / 2 if "x0" in year_cell else \
                (year_cell["bbox"][0] + year_cell["bbox"][2]) / 2
            best = None
            for c in nums:
                d = abs(c["xc"] - xc)
                if best is None or d < best[0]:
                    best = (d, c)
            if best is None:
                continue
            value_cell = best[1]
            unit = row_unit(norm(label_cell["text"])) or declared_unit(rows) or "元"
            facts.append(_emit_words_fact(
                material=material, page=page, metric="total_revenue",
                label=norm(label_cell["text"]), label_fragments=[label_cell],
                raw=value_cell["raw"], value=decimal(value_cell["text"]), unit=unit,
                year=yr, year_cell=year_cell, adjustment_cell=None,
                reported_yoy_cell=yoy, value_cell=value_cell,
                table_rows=rows, page_currency=currency_note,
                method="income_statement_total_revenue"))
    return facts


# ─────────────────────────── 统一入口 ───────────────────────────

def _apply_scope(document, sections, facts, material):
    """对 revenue / total_revenue / operating_cash_flow 做合并口径旁证。"""
    for metric in ("revenue", "total_revenue", "operating_cash_flow"):
        current = next((f for f in facts if f["metric"] == metric
                        and f["period_year"] == material["report_year"]
                        and f["adjustment"] == "as_reported"), None)
        corroboration = corroborate_scope(document, sections, current) if current else None
        for fact in facts:
            if fact["metric"] != metric:
                continue
            if corroboration:
                fact["scope"] = "consolidated"
                fact["scope_evidence"] = {
                    **corroboration, "application": "same_summary_metric_row",
                    "confirmed_current_evidence_id": current["evidence_id"]}
            elif "scope_unknown" not in fact["issues"]:
                fact["issues"].append("scope_unknown")


def _dedupe(facts: list[dict]) -> list[dict]:
    """同 (metric, period_year, adjustment) 只留一条；两通道都有时优先网格路径（护 gold）。"""
    order = {"grid_cells_and_geometric_headers": 0, "words_geometry": 1,
             "income_statement_total_revenue": 2}
    best: dict[tuple, dict] = {}
    for f in facts:
        key = (f["metric"], f["period_year"], f["adjustment"])
        old = best.get(key)
        if old is None or order.get(f["extraction_method"], 9) < order.get(old["extraction_method"], 9):
            best[key] = f
    return list(best.values())


def extract_material(root, material: dict, run: Run) -> list[dict]:
    path = within(root, root / material["local_file"])
    blob = run.read(path)
    if sha256(blob) != material["sha256"]:
        raise ValueError("提取前指纹复核失败")
    with pymupdf.open(stream=blob, filetype="pdf") as document:
        texts = [page.get_text() for page in document]
        currency = document_currency(document, texts)

        # ── 通道 1：表格线网格（gold 口径） ──
        grid_facts: list[dict] = []
        grid_error = None
        try:
            candidates = []
            for index, content in enumerate(texts):
                compact = norm(content)
                if "主要会计数据" not in compact or "营业收入" not in compact:
                    continue
                page = document[index]
                for ti, table in enumerate(page.find_tables().tables):
                    facts = parse_table(page, table, ti, material, currency)
                    current = [f for f in facts if f["period_year"] == material["report_year"]]
                    count = len({f["metric"] for f in current})
                    if count:
                        candidates.append((count, facts))
            if candidates:
                best_count = max(count for count, _ in candidates)
                best = [facts for count, facts in candidates if count == best_count]
                signatures = {
                    tuple(sorted((f["metric"], f["period_year"], f["adjustment"], f["value"] or "")
                                 for f in facts)) for facts in best}
                if len(signatures) != 1:
                    raise ValueError("发现互相冲突的候选表，需要人工选择")
                grid_facts = best[0]
                keys = [(f["metric"], f["period_year"], f["adjustment"]) for f in grid_facts]
                if len(keys) != len(set(keys)):
                    raise ValueError("表头产生重复证据键，拒绝静默选列")
        except ValueError as exc:
            grid_error = str(exc)

        # ── 通道 2：words 级（稳健） ──
        words_facts = extract_words_document(document, material, currency)

        # ── 通道 3：利润表补营业总收入 ──
        total_facts = extract_total_revenue(document, material, currency)

        facts = _dedupe(grid_facts + words_facts + total_facts)
        if not facts:
            raise ValueError(grid_error or "未识别年度主要会计数据表；可能无文字层或版式不支持")

        sections = statement_sections(document)
        _apply_scope(document, sections, facts, material)

        current_metrics = {f["metric"] for f in facts
                           if f["period_year"] == material["report_year"]
                           and f["adjustment"] in {"as_reported", "after"}}
        missing_required = [m for m in REQUIRED if m not in current_metrics]
        missing_optional = sorted(set(METRICS) - current_metrics)
        method_counts = {}
        for f in facts:
            method_counts[f["extraction_method"]] = method_counts.get(f["extraction_method"], 0) + 1
        run.event("extraction_completed", document_id=material["document_id"],
                  evidence_count=len(facts), missing_required=missing_required,
                  missing_current_metrics=missing_optional,
                  method_counts=method_counts,
                  needs_review=sum(bool(f["issues"]) for f in facts))
        if missing_required:
            raise ValueError("主要指标不完整：" + ",".join(missing_required))
        return facts
